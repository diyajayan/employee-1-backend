require('dotenv').config();
// Task1: initiate app and run server at 3000

const path=require('path');

// Task2: create mongoDB connection 


//Task 2 : write api with error handling and appropriate api mentioned in the TODO below





//TODO: get data from db  using api '/api/employeelist'




//TODO: get single data from db  using api '/api/employeelist/:id'





//TODO: send data from db using api '/api/employeelist'
//Request body format:{name:'',location:'',position:'',salary:''}






//TODO: delete a employee data from db by using api '/api/employeelist/:id'





//TODO: Update  a employee data from db by using api '/api/employeelist'
//Request body format:{name:'',location:'',position:'',salary:''}


//! dont delete this code. it connects the front end file.


// Import modules
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// Task1: initiate app and run server at 3000
app.use(express.static(path.join(__dirname + '/dist/Frontend')));
const PORT = 3000;

// Task2: create mongoDB connection
const mongoURL = "mongodb+srv://Anaswara301:Employee.env@cluster0.sjzdjoq.mongodb.net/employeedb?retryWrites=true&w=majority&appName=Cluster0"; 
// Example: mongodb+srv://<username>:<password>@cluster0.mongodb.net/employeedb?retryWrites=true&w=majority

mongoose.connect(mongoURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB Atlas"))
.catch(err => console.log("❌ MongoDB Connection Error:", err));

// Create Schema and Model
const employeeSchema = new mongoose.Schema({
    name: String,
    location: String,
    position: String,
    salary: Number
});

const Employee = mongoose.model('Employee', employeeSchema);

// -----------------------------
// API ROUTES
// -----------------------------

// TODO: get data from db using api '/api/employeelist'
app.get('/api/employeelist', async (req, res) => {
    try {
        const employees = await Employee.find();
        res.status(200).json(employees);
    } catch (error) {
        res.status(500).json({ message: "Error fetching employee data", error });
    }
});

// TODO: get single data from db using api '/api/employeelist/:id'
app.get('/api/employeelist/:id', async (req, res) => {
    try {
        const emp = await Employee.findById(req.params.id);
        if (!emp) return res.status(404).json({ message: "Employee not found" });
        res.status(200).json(emp);
    } catch (error) {
        res.status(500).json({ message: "Error fetching employee", error });
    }
});

// TODO: send data to db using api '/api/employeelist'
// Request body format: {name:'', location:'', position:'', salary:''}
app.post('/api/employeelist', async (req, res) => {
    try {
        const { name, location, position, salary } = req.body;
        const newEmp = new Employee({ name, location, position, salary });
        const savedEmp = await newEmp.save();
        res.status(201).json(savedEmp);
    } catch (error) {
        res.status(500).json({ message: "Error adding employee", error });
    }
});

// TODO: delete employee data from db by using api '/api/employeelist/:id'
app.delete('/api/employeelist/:id', async (req, res) => {
    try {
        const deletedEmp = await Employee.findByIdAndDelete(req.params.id);
        if (!deletedEmp) return res.status(404).json({ message: "Employee not found" });
        res.status(200).json({ message: "Employee deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting employee", error });
    }
});

// TODO: update employee data from db by using api '/api/employeelist'
// Request body format: { _id:'', name:'', location:'', position:'', salary:'' }
app.put('/api/employeelist', async (req, res) => {
    try {
        const { _id, name, location, position, salary } = req.body;
        if (!_id) return res.status(400).json({ message: "Employee ID is required for update" });

        const updatedEmp = await Employee.findByIdAndUpdate(
            _id,
            { name, location, position, salary },
            { new: true }
        );

        if (!updatedEmp) return res.status(404).json({ message: "Employee not found" });
        res.status(200).json(updatedEmp);
    } catch (error) {
        res.status(500).json({ message: "Error updating employee", error });
    }
});

//! don't delete this code. it connects the front end file.
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'Frontend', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});